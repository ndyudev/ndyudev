<div align="center">
    <img src="https://user-images.githubusercontent.com/73995275/222146888-2ac7f3cc-a14b-4b98-9bd2-16fa99ea11f8.png">
    <br>
</div>

<h1 align="center">📝 About me:</h1>

```py
const UserInformation = {
 pronouns: "He" | "Him",
    askMeAbout: ["web developer"],
    technologies:{
        fronend: ["react-native","reactjs", "nextjs"],
        backend: ["nodejs", "express"],
        database: ["mongo","mysql"],
        others:["Photoshop", "Illustraion", "Figma"]
    },
    interests: ["music"]
}
```

[![committers.top badge](https://user-badge.committers.top/vietnam/hongducdev.svg)](https://user-badge.committers.top/vietnam/hongducdev) <img src="https://komarev.com/ghpvc/?username=hongducdev&label=Profile%20views&color=0e75b6&style=flat" alt="hongducdev" /> 


<h1 align="center">📊 My Github Stats:</h1>

<div align=center>
    <img
        width="396"
        src="https://github-readme-stats.vercel.app/api?username=hongducdev&show_icons=true&bg_color=1e1e2e&text_color=cdd6f4&icon_color=cba6f7&title_color=a6e3a1"
    />
    <img
        width="396"
        src="https://github-readme-stats.vercel.app/api/top-langs/?username=hongducdev&show_icons=true&layout=compact&bg_color=1e1e2e&text_color=cdd6f4&icon_color=cba6f7&title_color=a6e3a1"
    />
</div>

<h1 align="center">🌐 Connect with me:</h1>
<p align="center">
    <a href="https://www.facebook.com/hongducdev/" target="_blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="https://www.facebook.com/d4rtj" height="30" width="30" /></a>
    <a href="https://discord.com/users/769244837030526976" target="_blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/discord.svg" alt="https://discord.com/users/968119621544710195" height="40" width="50" /></a>
    <a href="https://www.instagram.com/pinkduwc._/" target="_blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="https://www.instagram.com/d4rtj/" height="30" width="30" /></a>
    <!-- linkedin -->
    <a href="https://www.linkedin.com/in/nguy%E1%BB%85n-h%E1%BB%93ng-%C4%91%E1%BB%A9c-aa609220a/" target="_blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="https://www.linkedin.com/in/nguy%E1%BB%85n-h%E1%BB%93ng-%C4%91%E1%BB%A9c-aa609220a/" height="30" width="30" /></a>
</p>

<h1 align="center">📚 Languages and Tools:</h1>
<p align="center">
    <img src="https://skillicons.dev/icons?i=c,cpp,cs,java,js,ts,html,css,bootstrap,styledcomponents,tailwind,androidstudio,devto,discord,bots,dotnet,express,figma,firebase,git,github,heroku,ai,instagram,linkedin,linux,md,materialui,mongodb,mysql,netlify,nextjs,nodejs,postman,powershell,react,redux,sqlite,stackoverflow,svg,vercel,visualstudio,vite,vscode&theme=dark" alt="Languages and Tools" />

</p>

<footer align="center" >
  <img align="center" alt="colored gif" src="https://capsule-render.vercel.app/api?type=waving&color=gradient&height=200&section=footer" />
</footer>
